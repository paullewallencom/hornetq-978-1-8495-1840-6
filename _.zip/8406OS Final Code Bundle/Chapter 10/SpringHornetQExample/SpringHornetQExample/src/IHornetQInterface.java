
public interface IHornetQInterface {
	public void ProduceConsumeMessage();
}
